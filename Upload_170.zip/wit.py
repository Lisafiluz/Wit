from pathlib import Path
import sys


def init() -> None:
    path = Path.cwd() / ".wit"
    path.mkdir()
    directories_to_create = ["images", "staging_area"]
    for in_dir in directories_to_create:
        new_path = path / in_dir
        new_path.mkdir()


if __name__ == "__main__":
    argvs = sys.argv
    if len(argvs) == 2:
        if argvs[1] == "init":
            init()