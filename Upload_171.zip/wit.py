import datetime
from distutils.dir_util import copy_tree
from pathlib import Path
import shutil
import sys


LOG_PATH = Path.cwd() / "log.txt"


def log(message: str) -> None:
    time = datetime.datetime.now()
    log_to_add = f"{time} : {message}\n"
    try:
        with open(LOG_PATH, "w+") as log_file:
            log_file.write(log_to_add)
    except FileNotFoundError:
        raise


def init() -> None:
    path = Path.cwd() / ".wit"
    path.mkdir()
    directories_to_create = ["images", "staging_area"]
    for in_dir in directories_to_create:
        new_path = path / in_dir
        new_path.mkdir()
    log("Success - .wit directory created with images and staging_area sub-directories")


def is_wit_dir_in_path(path: Path) -> bool:
    parents = list(path.parents)
    wit_path = Path(Path.cwd() / ".wit")
    for parent in parents:
        if wit_path in list(parent.iterdir()):
            return True 
    return False


def add(path: str) -> None:
    new_path = Path(path).absolute()
    if new_path.is_dir() or new_path.is_file():
        if new_path.exists():
            if is_wit_dir_in_path(new_path):
                parents = list(new_path.parents)
                start_creation = False
                wit_path = Path(Path.cwd() / ".wit")
                staging_area_path = wit_path / "staging_area"
                for parent in parents[-1::-1]:
                    if start_creation:
                        if not (staging_area_path / parent.name).exists():
                            (staging_area_path / parent.name).mkdir()
                        staging_area_path = (staging_area_path / parent.name)
                    if wit_path in list(parent.iterdir()):
                        start_creation = True
                try:
                    if new_path.is_file():
                        file_name = Path(staging_area_path / new_path.name)
                        shutil.copyfile(path, file_name.__str__())
                    else:
                        directory_name = Path(staging_area_path / new_path.name)
                        copy_tree(path, directory_name.__str__())
                    
                except Exception as err:
                    log(f"Error - {err}")
                
            else:
                log(f"Error - wit directory not found in -> {path}")
        else:
            log(f"Error - no file / directory in path -> {path}")
    else:
        log(f"Error - invalid path -> {path}")


if __name__ == "__main__":
    argvs = sys.argv
    print(argvs)
    if len(argvs) == 2:
        if argvs[1] == "init":
            init()
    elif len(argvs) == 3:
        print(1)
        if argvs[1] == "add":
            add(argvs[2])
