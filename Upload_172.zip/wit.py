import datetime
from distutils.dir_util import copy_tree
import fileinput
from pathlib import Path
import random
import shutil
import sys
from time import gmtime, strftime


LOG_PATH = Path.home() / "log.txt"
WIT_PATH = Path.home() / ".wit"
STAGING_AREA_PATH = Path.home() / ".wit" / "staging_area"
IMAGES_PATH = Path.home() / ".wit" / "images"
REFERENCES_PATH = Path.home() / ".wit" / "references.txt"


def log(message: str) -> None:
    time = datetime.datetime.now()
    log_to_add = f"{time} : {message}\n"
    try:
        if not LOG_PATH.exists():
            with open(LOG_PATH, "w+") as log_file:
                log_file.write(log_to_add)
        else:
            with open(LOG_PATH, "a") as log_file:
                log_file.write(log_to_add)
    except FileNotFoundError:
        raise


def init() -> None:
    WIT_PATH.mkdir()
    STAGING_AREA_PATH.mkdir()
    IMAGES_PATH.mkdir()
    log("Success - .wit directory created with images and staging_area sub-directories")


def is_wit_dir_in_path(path: Path) -> bool:
    parents = list(path.parents)
    for parent in parents:
        if WIT_PATH in list(parent.iterdir()):
            return True 
    return False


def add(path: str) -> None:
    new_path = Path(path).absolute()
    if new_path.is_dir() or new_path.is_file():
        if new_path.exists():
            if is_wit_dir_in_path(new_path):
                parents = list(new_path.parents)
                start_creation = False
                in_dir = STAGING_AREA_PATH
                for parent in parents[-1::-1]:
                    if start_creation:
                        in_dir = in_dir / parent.name
                        if not in_dir.exists():
                            in_dir.mkdir()
                    if WIT_PATH in list(parent.iterdir()):
                        start_creation = True
                try:
                    if new_path.is_file():
                        file_name = in_dir / new_path.name
                        shutil.copyfile(path, str(file_name))
                    else:
                        directory_name = in_dir / new_path.name
                        copy_tree(path, str(directory_name))
                    
                except Exception as err:
                    log(f"Error - {err}")
                
            else:
                log(f"Error - wit directory not found in -> {path}")
        else:
            log(f"Error - no file / directory in path -> {path}")
    else:
        log(f"Error - invalid path -> {path}")


def get_commit_id() -> str:
    characthers = "1234567890abcdef"
    length = 40
    commit_id = ''.join(random.choice(characthers) for _ in range(length))
    return commit_id


def get_parent():
    if not REFERENCES_PATH.exists():
        return None
    else:
        try:
            with open(str(REFERENCES_PATH), 'r') as file:
                file_txt = file.readlines()
        except PermissionError as err:
            log(err)
        else:
            parent_head = file_txt[0][file_txt[0].find("=") + 1:-1]
            return parent_head


def create_metadata_file(commit_id: str, message: str, images_path: Path) -> None:
    text_to_add = ""
    parent = get_parent()
    row1 = f"parent={parent}\n"
    time_zone = strftime("%z", gmtime())
    time = datetime.datetime.now().strftime(f"%a %b %d %X %Y{time_zone}")
    row2 = f"date={time}\n"
    row3 = f"message={message}\n"
    text_to_add += row1
    text_to_add += row2
    text_to_add += row3
    file_name = commit_id + ".txt"
    file_path = images_path / file_name
    try:
        with open(file_path, 'w+') as file_handler:
            file_handler.write(text_to_add)
    except PermissionError as err:
        log(err)


def copy_staging_area_content(source_dir: Path, dest_dir: Path) -> None:
    try:
        copy_tree(str(source_dir), str(dest_dir))
    except Exception as err:
        log(err)


def update_references_file(commit_id: str) -> None:
    if not REFERENCES_PATH.exists():
        try:
            file = open(str(REFERENCES_PATH), 'w+')
            file.write("HEAD=\nmaster=\n")
        except PermissionError as err:
            print(err)
        finally:
            file.close()
    for line in enumerate(fileinput.input(str(REFERENCES_PATH), inplace=1)):
        sys.stdout.write(line[1][:line[1].find('=') + 1] + commit_id)
        sys.stdout.write("\n")


def commit(message: str):
    cwd_path = Path.cwd().absolute()
    if is_wit_dir_in_path(cwd_path):
        commit_id = get_commit_id()
        commit_path = IMAGES_PATH / commit_id
        if not commit_path.exists():
            commit_path.mkdir()
            create_metadata_file(commit_id, message, IMAGES_PATH)
            copy_staging_area_content(STAGING_AREA_PATH, commit_path)
            update_references_file(commit_id)
        else:
            commit(message)  # Until we get diffrent commit id
    else:
        log(f"Error - wit directory not found in -> {cwd_path}")


if __name__ == "__main__":
    argvs = sys.argv
    print(argvs)
    if len(argvs) == 2:
        if argvs[1] == "init":
            init()
    elif len(argvs) == 3:
        print(1)
        if argvs[1] == "add":
            add(argvs[2])
        elif argvs[1] == "commit":
            commit(argvs[2])